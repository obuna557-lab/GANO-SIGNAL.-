package uz.gano.signal;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.os.IBinder;
public class KeepService extends Service{
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent in,int f,int sid){
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
  nm.createNotificationChannel(new NotificationChannel("keep","Budilniklar faol",NotificationManager.IMPORTANCE_MIN));
  PendingIntent pi=PendingIntent.getActivity(this,9,new Intent(this,MainActivity.class),PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(this,"keep").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Gano Signal faol").setContentIntent(pi).setOngoing(true).build();
  startForeground(2,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
  Alarm.log(this,"xizmat ishga tushdi");
  return START_STICKY;}
}
