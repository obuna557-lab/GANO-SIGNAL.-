package uz.gano.signal;
import android.content.*;
public class AlarmActionReceiver extends BroadcastReceiver{
 static final String TAKEN="uz.gano.signal.TAKEN",SNOOZE="uz.gano.signal.SNOOZE";
 public void onReceive(Context c,Intent in){
  String a=in.getAction();int id=in.getIntExtra("id",-1);
  Alarm.log(c,"tugma: "+(TAKEN.equals(a)?"ICHDIM":SNOOZE.equals(a)?"5 DAQIQA":"?")+" id="+id);
  if(id<0)return;
  if(TAKEN.equals(a))Alarm.addRing(c,id);
  else if(SNOOZE.equals(a))Alarm.snooze(c,id);
  else return;
  AlarmService s=AlarmService.cur;
  if(s!=null)s.end("tugma");else Alarm.log(c,"xizmat yo'q (signal allaqachon tugagan)");
 }}
