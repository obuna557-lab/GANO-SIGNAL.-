package uz.gano.signal;
import android.app.*;import android.content.*;import android.graphics.*;import android.os.*;import android.view.*;import android.widget.*;
public class AlarmActivity extends Activity{
 Handler h=new Handler(Looper.getMainLooper());int curId;
 protected void onCreate(Bundle b){super.onCreate(b);
  setShowWhenLocked(true);setTurnScreenOn(true);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
  show(getIntent());poll();}
 protected void onNewIntent(Intent in){super.onNewIntent(in);setIntent(in);show(in);} // yangi signal: yangi mahsulot
 void show(Intent in){
  curId=in.getIntExtra("id",0);String name=in.getStringExtra("name");
  Alarm.log(this,"oyna ochildi id="+curId);
  LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER);l.setPadding(40,40,40,40);l.setBackgroundColor(0xFF0F0B0B);
  try{ImageView iv=new ImageView(this);iv.setImageBitmap(BitmapFactory.decodeStream(getAssets().open("images/"+(curId/2+1)+".jpg")));iv.setScaleType(ImageView.ScaleType.CENTER_CROP);l.addView(iv,500,500);}catch(Exception e){}
  TextView t=new TextView(this);t.setText(name+"\nQabul vaqti!");t.setTextSize(24);t.setTextColor(0xFFD4AF37);t.setGravity(Gravity.CENTER);l.addView(t);
  Button ok=new Button(this);ok.setText("✅ OK, ichdim");ok.setTextSize(20);
  ok.setOnClickListener(v->send(AlarmActionReceiver.TAKEN));
  Button sn=new Button(this);sn.setText("⏱ 5 daqiqadan keyin");sn.setTextSize(18);
  sn.setOnClickListener(v->send(AlarmActionReceiver.SNOOZE));
  l.addView(ok);l.addView(sn);setContentView(l);}
 void send(String act){sendBroadcast(new Intent(this,AlarmActionReceiver.class).setAction(act).putExtra("id",curId));finish();}
 void poll(){h.postDelayed(()->{if(!AlarmService.ringing)finish();else poll();},1000);}
 protected void onDestroy(){h.removeCallbacksAndMessages(null);super.onDestroy();}
}
