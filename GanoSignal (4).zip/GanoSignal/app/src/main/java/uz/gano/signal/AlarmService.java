package uz.gano.signal;
import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.graphics.drawable.Icon;import android.media.*;import android.net.Uri;import android.os.*;
public class AlarmService extends Service{
 static volatile boolean ringing=false;
 static volatile AlarmService cur;
 MediaPlayer mp;Vibrator vb;PowerManager.WakeLock wl;Handler h=new Handler(Looper.getMainLooper());
 public IBinder onBind(Intent i){return null;}
 public void onCreate(){super.onCreate();cur=this;}
 public int onStartCommand(Intent in,int f,int sid){
  if(in==null){stopSelf();return START_NOT_STICKY;}
  int id=in.getIntExtra("id",0);String name=in.getStringExtra("name");
  Alarm.log(this,"signal boshlandi id="+id+" "+name+(ringing?" (oldingisini almashtirdi)":""));
  NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
  nm.createNotificationChannel(new NotificationChannel("ring","Budilnik",NotificationManager.IMPORTANCE_HIGH));
  int fl=PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE;
  PendingIntent full=PendingIntent.getActivity(this,300+id,new Intent(this,AlarmActivity.class).putExtra("id",id).putExtra("name",name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),fl);
  PendingIntent ok=PendingIntent.getBroadcast(this,100+id,new Intent(this,AlarmActionReceiver.class).setAction(AlarmActionReceiver.TAKEN).putExtra("id",id),fl);
  PendingIntent sn=PendingIntent.getBroadcast(this,200+id,new Intent(this,AlarmActionReceiver.class).setAction(AlarmActionReceiver.SNOOZE).putExtra("id",id),fl);
  Icon ic=Icon.createWithResource(this,android.R.drawable.ic_lock_idle_alarm);
  Notification n=new Notification.Builder(this,"ring").setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(name).setContentText("Qabul vaqti!")
   .setCategory(Notification.CATEGORY_ALARM).setOngoing(true).setFullScreenIntent(full,true).setContentIntent(full)
   .addAction(new Notification.Action.Builder(ic,"Ichdim",ok).build()).addAction(new Notification.Action.Builder(ic,"5 daqiqadan keyin",sn).build()).build();
  try{startForeground(1,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);}catch(Exception e){Alarm.log(this,"startForeground xato: "+e.getClass().getSimpleName());}
  ringing=true;
  PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
  if(wl==null){wl=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"gano:alarm");wl.acquire(6*60000L);}
  int[] types={RingtoneManager.TYPE_ALARM,RingtoneManager.TYPE_RINGTONE,RingtoneManager.TYPE_NOTIFICATION};
  for(int ty:types){try{Uri u=RingtoneManager.getDefaultUri(ty);if(mp!=null)mp.release();mp=new MediaPlayer();mp.setDataSource(this,u);
   mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
   mp.setLooping(true);mp.prepare();mp.start();break;}catch(Exception e){Alarm.log(this,"ovoz xato (tur "+ty+"): "+e.getClass().getSimpleName());}}
  vb=(Vibrator)getSystemService(VIBRATOR_SERVICE);vb.vibrate(VibrationEffect.createWaveform(new long[]{0,500,300,500,300},0));
  try{startActivity(new Intent(this,AlarmActivity.class).putExtra("id",id).putExtra("name",name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));}
  catch(Exception e){Alarm.log(this,"oyna ochilmadi: "+e.getClass().getSimpleName());}
  h.removeCallbacksAndMessages(null);
  h.postDelayed(()->end("vaqt tugadi"),Alarm.p(this).getInt("ringMin",4)*60000L);
  return START_NOT_STICKY;}
 void end(String why){Alarm.log(this,"signal tugadi: "+why);ringing=false;h.removeCallbacksAndMessages(null);
  try{if(mp!=null){mp.stop();mp.release();mp=null;}}catch(Exception e){}
  if(vb!=null)vb.cancel();if(wl!=null&&wl.isHeld())wl.release();wl=null;
  stopForeground(STOP_FOREGROUND_REMOVE);stopSelf();}
 public void onDestroy(){ringing=false;if(cur==this)cur=null;super.onDestroy();}
}
