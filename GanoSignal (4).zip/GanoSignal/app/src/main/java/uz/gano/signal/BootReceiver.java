package uz.gano.signal;
import android.content.*;
public class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){String a=i.getAction();
 Alarm.log(c,"yonish: "+(a==null?"?":a.substring(a.lastIndexOf('.')+1)));
 Alarm.rescheduleAll(c,a!=null&&(a.contains("BOOT")||a.contains("QUICKBOOT")));
 if("android.intent.action.BOOT_COMPLETED".equals(a)||"android.intent.action.MY_PACKAGE_REPLACED".equals(a)){
  try{c.startForegroundService(new Intent(c,KeepService.class));}catch(Exception e){Alarm.log(c,"xizmat: "+e.getClass().getSimpleName());}}}}
