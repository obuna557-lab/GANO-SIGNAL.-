package uz.gano.signal;
import android.app.*;import android.content.*;import java.util.*;import org.json.*;
public class Alarm{
 static SharedPreferences p(Context c){Context d=c.isDeviceProtectedStorage()?c:c.createDeviceProtectedStorageContext();return d.getSharedPreferences("gano",0);}
 static PendingIntent fire(Context c,int id,boolean sn){
  Intent i=new Intent(c,AlarmReceiver.class).putExtra("id",id).putExtra("snooze",sn).setAction("fire"+id+sn);
  return PendingIntent.getBroadcast(c,sn?id+1000:id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static void set(Context c,int id,long t,boolean sn){
  try{AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
   PendingIntent show=PendingIntent.getActivity(c,5000+id,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   am.setAlarmClock(new AlarmManager.AlarmClockInfo(t,show),fire(c,id,sn));
   if(!sn)p(c).edit().putLong("next"+id,t).apply();
  }catch(Exception e){p(c).edit().putString("err","setAlarm: "+e).apply();}}
 static long nextTime(int h,int m){Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,h);c.set(Calendar.MINUTE,m);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
  if(c.getTimeInMillis()<=System.currentTimeMillis()+1000)c.add(Calendar.DAY_OF_YEAR,1);return c.getTimeInMillis();}
 static void schedule(Context c,int id,int h,int m,String name,int idx){p(c).edit().putString("a"+id,h+"|"+m+"|"+name+"|"+idx).apply();set(c,id,nextTime(h,m),false);}
 static void cancel(Context c,int id){boolean had=p(c).contains("a"+id);AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  am.cancel(fire(c,id,false));am.cancel(fire(c,id,true)); // kechiktirilgan signal ham bekor
  p(c).edit().remove("a"+id).remove("next"+id).apply();if(had)log(c,"bekor qilindi id="+id+" (kechiktirilgani ham)");}
 static void snooze(Context c,int id){long t=System.currentTimeMillis()+5*60000L;set(c,id,t,true);
  log(c,"keyinroq qo'yildi id="+id+" -> "+new java.text.SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date(t)));}
 static void rescheduleAll(Context c){rescheduleAll(c,false);}
 static void rescheduleAll(Context c,boolean boot){long now=System.currentTimeMillis();
  for(int id=0;id<42;id++){String s=p(c).getString("a"+id,null);if(s==null)continue;String[] a=s.split("\\|",4);int h=Integer.parseInt(a[0]),m=Integer.parseInt(a[1]);
   if(boot){Calendar t=Calendar.getInstance();t.set(Calendar.HOUR_OF_DAY,h);t.set(Calendar.MINUTE,m);t.set(Calendar.SECOND,0);t.set(Calendar.MILLISECOND,0);long t0=t.getTimeInMillis();
    if(t0<=now&&now-t0<=15*60000L&&p(c).getLong("last"+id,0)<t0){p(c).edit().putLong("last"+id,now).apply();set(c,id,now+3000,true);}} // telefon o'chiq paytida o'tib ketgan signal
   set(c,id,nextTime(h,m),false);}}
 static void log(Context c,String m){try{SharedPreferences p=p(c);String[] o=p.getString("log","").split("\n");StringBuilder b=new StringBuilder();
  for(int i=Math.max(0,o.length-59);i<o.length;i++)if(!o[i].isEmpty())b.append(o[i]).append('\n');
  b.append(new java.text.SimpleDateFormat("dd.MM HH:mm:ss",Locale.US).format(new Date())).append(' ').append(m);p.edit().putString("log",b.toString()).apply();}catch(Exception e){}}
 static void checkMissed(Context c){long now=System.currentTimeMillis();java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("dd.MM HH:mm",Locale.US);
  for(int id=0;id<42;id++){String s=p(c).getString("a"+id,null);if(s==null)continue;long nx=p(c).getLong("next"+id,0),ls=p(c).getLong("last"+id,0);
   if(nx>0&&nx<now-60000&&ls<nx)log(c,"CHALINMADI: "+s.split("\\|",4)[2]+" ("+(id%2+1)+") "+f.format(new Date(nx)));}}
 static void addRing(Context c,int id){if(id<0||id>=42){log(c,"hisob: id="+id+" e'tiborsiz (sinov)");return;}try{JSONArray ar=new JSONArray(p(c).getString("rings","[]"));
  ar.put(new JSONObject().put("i",id/2).put("k",id%2).put("t",System.currentTimeMillis()));p(c).edit().putString("rings",ar.toString()).apply();log(c,"hisob navbatiga yozildi id="+id);}catch(Exception e){log(c,"hisob xato: "+e);}}
}
